
public class Main {

	public static void main(String[] args) {
		
		Bus bus = new Bus();
		
		Student[] student = new Student[25];
		
		
		
	}

}
