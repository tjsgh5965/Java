
public class Subway {
	private int needMoney;
	private int maxMemberCount;
	int memberCount;
	
	Subway() {
		this.needMoney = 600;
		this.maxMemberCount = 20;
		this.memberCount = 0;
	}
	
	int wantToMoney() {
		return this.needMoney;
	}
	void takeOnIt(Student st, boolean isTransfer) {
		
	}
	void takeOffIt(Student st, boolean isTransfer) {
		
	}
}
